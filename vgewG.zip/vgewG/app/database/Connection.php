<?php

namespace app\database;

use PDO;

class Connection
{
     #Variavel de conexão com banco de dados
     private static $pdo = null;
     #Método de conxão com banco de dados
     public static function connection(): PDO
     {
       try{
     
          #caso na exista a conexão com banco de dados retornamos a conexão
          if (static::$pdo) {
               return static::$pdo;
          }
          # Definindo as opções para a conexão PDO.
          $options = [
          PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,  # Lança exceções em caso de erros.
          PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,  # Define o modo de fetch padrão como array associativo.
          PDO::ATTR_EMULATE_PREPARES => false,  # Desativa a emulação de prepared statements.
          PDO::ATTR_PERSISTENT => true,  # Conexão persistente para melhorar performance.
          PDO::ATTR_STRINGIFY_FETCHES => false,  # Desativa a conversão de valores numéricos para strings.
     ];
          # Criação da nova conexão PDO com os parâmetros do banco de dados.
          static::$pdo = new PDO(
          'pgsql:host=localhost;port=5432;dbname=integra_development',  # DSN (Data Source Name) para PostgreSQL.
          'integra',  # Nome de usuário do banco de dados.
          '@w906083W@',  # Senha do banco de dados.
          $options  # Opções para a conexão PDO.
     );

          static::$pdo->exec("SET NAMES 'utf8'");
          # Caso seja bem-sucedida a conexão, retornamos a variável $pdo.
          return static::$pdo;
        } catch (\PDOException $e) {
          throw new \PDOException("Erro: " . $e->getMessage(), 1);
       }
     }
}