<?php

define('ROOT', dirname(__FILE__, 3));

define('EXT_VIEW', '.html');

define('DIR_VIEW', ROOT . '/app/view');
